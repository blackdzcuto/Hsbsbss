### Hello everyone, thank you for visiting my Github!!! 👋

## I'm [J-JRT!](https://www.facebook.com/NHD.JRT.262) 👋
<h1 align="center">
    <img src="home/img.svg"/>
</h1>
<a href="#" target="_blank">
  <img src="home/J-JRT.svg" width="1200" alt="Click to see the source" />
</a>

# 📰 Talking about Information
<img align="right" width=200px alt="PNG" src="https://i.pinimg.com/originals/a0/10/21/a010215b786ada4176ae237b5b154310.gif" />

-   ⚜️ My name is Nguyễn Hải Đăng.
-   ❤️‍🔥 26/02/2003
-   💬 My nickname is JRT
-   💬 My rela is Nguyễn Hồng Phấn ( Tracy )
-   💓 Relationship: hẹn hò
-   🍁 Profile: [Facebook](https://www.facebook.com/NHD.JRT.262)
-   🍀 Describe yourself: I love to travel with my lover and travel to explore. Although I am a quiet person, but anyone who comes into contact with me, I am willing to open my heart. And especially I love this girl very much with all my heart and what I give her will be true and nothing more than that, friendship will rank 2nd and my lover will be 1st.
<hr>

# 📖 Top Langs
![](https://github.com/Platane/snk/raw/output/github-contribution-grid-snake.svg)
![Hello](home/hello.svg)
# 🤝🏻 Connect with Me
<p align="center">
&nbsp; <a href="https://www.instagram.com/hd.jrt.2k3" target="_blank" rel="noopener noreferrer"><img src="https://img.icons8.com/plasticine/100/000000/instagram-new.png" width="100" /></a>    
&nbsp; <a href="https://github.com/J-JRT" target="_blank" rel="noopener noreferrer"><img src="https://img.icons8.com/plasticine/100/000000/github.png" width="100" /></a>
&nbsp; <a href="https://www.facebook.com/NHD.JRT.262" target="_blank" rel="noopener noreferrer"><img src="https://img.icons8.com/plasticine/100/000000/facebook.png"  width="100" /></a>
&nbsp; <a href="mailto:lehonguyen2k3@gmail.com" target="_blank" rel="noopener noreferrer"><img src="https://img.icons8.com/plasticine/100/000000/gmail.png"  width="100" /></a>
</p>
<br>
<a href="#" target="_blank">
  <img src="home/profile-night-view.svg" width="1200" alt="Click to see the source" />
</a>  
</a>
