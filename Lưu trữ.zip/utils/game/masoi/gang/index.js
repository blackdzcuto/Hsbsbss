module.exports = {
	Werewolf: require('./Werewolf.gang'),
	Isolate: require('./Isolate.gang')
};
